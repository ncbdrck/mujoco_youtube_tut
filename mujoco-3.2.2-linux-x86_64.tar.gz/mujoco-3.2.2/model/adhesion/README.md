# Active adhesion example

This example model shows how to use adhesion actuators.

The video below is a screen capture of a user interacting with the model:


[![Active adhesion example model](https://img.youtube.com/vi/BcHZ5BFeTmU/0.jpg)](https://www.youtube.com/watch?v=BcHZ5BFeTmU)

